package com.queen.insight.linux;

public class JSONObject {

	public static JSONObject fromObject(String param) {
		// TODO Auto-generated method stub
		return null;
	}

	public static SftpConfig toBean(JSONObject jsonObj, Class<SftpConfig> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
