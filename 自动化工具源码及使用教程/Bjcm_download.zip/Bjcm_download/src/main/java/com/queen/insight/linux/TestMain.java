package com.queen.insight.linux;

import org.apache.commons.lang3.StringUtils;

public class TestMain {

	/**
	 * @author shangjinlong
	 * 
	 * 需要手动填写服务器ip、用户名、密码
	 * 
	 */
	public static void main(String[] args) {

		SftpConfig sftpConfig = new SftpConfig();
		sftpConfig.setIp("172.16.34.151");
		sftpConfig.setPwd("6789@jkl");
		sftpConfig.setUsername("root");
		String fileName1 = "1301_1301E_1_11066600000000_1235BAB38BA37D290447BDBE9FFBC3D3_83FDC2595AE3BC336420C0A04ADEFF73.zip";
		String name1 = "";
		if (StringUtils.isNotBlank(fileName1)) {
			if (fileName1.contains("_")) {
				name1 = fileName1.substring(0, fileName1.lastIndexOf("_"));
				name1 = name1.substring(0, name1.lastIndexOf("_"));
				name1 = name1.substring(0, name1.lastIndexOf("_"));
			}
		}
		// System.out.println(name1);
		SFTPUtil.down(sftpConfig, "/bjcm/fy/receive/data", name1, "F:\\BJCM\\下载包\\");
		System.out.println("------------------------------");
		SFTPUtil.down(sftpConfig, "/bjcm/gaj/receive/data", name1, "F:\\BJCM\\下载包\\");
		System.out.println("------------------------------");
		SFTPUtil.down(sftpConfig, "/bjcm/jcy/receive/data", name1, "F:\\BJCM\\下载包\\");
		System.out.println("------------------------------");
		SFTPUtil.down(sftpConfig, "/bjcm/kss/receive/data", name1, "F:\\BJCM\\下载包\\");
		System.out.println("------------------------------");
		SFTPUtil.down(sftpConfig, "/bjcm/sfj/receive/data", name1, "F:\\BJCM\\下载包\\");
	}
}
