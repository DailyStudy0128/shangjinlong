package com.queen.insight.linux;

import org.apache.commons.lang3.StringUtils;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;

import java.util.Vector;

public class SFTPUtil {

//    private static System.out.println System.out.println = System.out.printlnFactory.getSystem.out.println(SFTPUtil.class);

	/**
	 * 获取Sftp对象
	 * 
	 * @param param
	 * @return
	 */
	public static SftpConfig getSftpObj(String param) {
		SftpConfig sftpConfig = new SftpConfig();
		if (StringUtils.isNotBlank(param)) {
			JSONObject jsonObj = JSONObject.fromObject(param);
			sftpConfig = (SftpConfig) JSONObject.toBean(jsonObj, SftpConfig.class);
		}
		return sftpConfig;
	}


	/**
	 * 根据文件名前缀下载文件
	 * 
	 * @param config
	 * @param baseDir
	 * @param fileNamePrefix
	 * @param filePath
	 * @return
	 */
	public static boolean down(SftpConfig config, String baseDir, String fileNamePrefix, String filePath) {
		SftpChannel sftpChannel = new SftpChannel();
		ChannelSftp sftp = null;
		try {
			if (StringUtils.isNotBlank(config.getPrivateKeyPath())) {
				sftp = sftpChannel.connectByIdentity(config);
			} else {
				sftp = sftpChannel.connectByPwd(config);
			}
			if (sftp.isConnected()) {
				System.out.println("连接服务器成功");
			} else {
				System.out.println("连接服务器失败");
				return false;
			}

			Vector<?> ls = sftp.ls(baseDir);
			String realFileName = "";
			for (Object file : ls) {
				if (file instanceof ChannelSftp.LsEntry) {
					String filename = ((ChannelSftp.LsEntry) file).getFilename();
                    //System.out.println(filename);
					//检查数据包是否以指定的前缀开始
					if (filename.startsWith(fileNamePrefix)) {
						realFileName = filename;
						break;
					}
				}
			}
			String dst = "";
			dst = filePath + realFileName;
			String src = baseDir + "/" + realFileName;
			System.out.println("数据包开始下载，bjcm服务器路径：[" + src + "]");
			System.out.println("目标服务器路径：[" + dst + "]");
			sftp.get(src, dst);
			System.out.println("数据包下载成功,已保存到本地路径");
			return true;
		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("该路径下无此数据包，无法下载");
			return false;
		} finally {
			sftpChannel.closeChannel();
		}
	}

	/**
	 * 判断文件夹是否存在 true 目录创建成功，false 目录创建失败
	 * 
	 * @param sftp
	 * @param filePath 文件夹路径
	 * @return
	 */
	public static boolean isExist(ChannelSftp sftp, String filePath) {
		String paths[] = filePath.split("\\/");
		String dir = paths[0];
		for (int i = 0; i < paths.length - 1; i++) {
			dir = dir + "/" + paths[i + 1];
			try {
				sftp.cd(dir);
			} catch (SftpException sException) {
				if (ChannelSftp.SSH_FX_NO_SUCH_FILE == sException.id) {
					try {
						sftp.mkdir(dir);
					} catch (SftpException e) {
						e.printStackTrace();
						return false;
					}
				}
			}
		}
		return true;
	}

}